const KEY = "de614a97";
const id = new URLSearchParams(window.location.search).get('id');
'use strict';

function search() {
    fetch("http://www.omdbapi.com/?apikey=" + KEY + "&i=" + id)
        .then(res => res.json())
        .then(json => placePoster(json))
        .catch(err => console.error(err));
}

function extraImage(post) {
    if (post === "N/A") {
        return "https://pbs.twimg.com/profile_images/1185757909604425729/FLXwFAF5_400x400.jpg";
    }
    else return post;
}


function placePoster(json){
    console.log(json);
    let card = document.createElement('div');
    card.className = "card m-5 w-200";

    let title = document.createElement('p');
    title.innerText = json.Title;
    card.appendChild(title).style.fontSize = "xx-large";;

    let poster = document.createElement('img');
    poster.src = extraImage(json.Poster);
    card.appendChild(poster);

    let year = document.createElement('p');
    year.innerText = "Year realeased: " + json.Year;
    card.appendChild(year);

    let country=document.createElement('p');
    country.innerText= "Country: " + json.Country;
    card.appendChild(country);

    let directors=document.createElement('p');
    directors.innerText= "Directed by: " + json.Director;
    card.appendChild(directors);

    let genre=document.createElement('p');
    genre.innerText= "Genre: " + json.Genre;
    card.appendChild(genre);

    let time=document.createElement('p');
    time.innerText= "Run-time: " +json.Runtime;
    card.appendChild(time);

    let rating=document.createElement('p');
    rating.innerText= "Rated: " +json.Rated;
    card.appendChild(rating);

    mainCard.appendChild(card);

}