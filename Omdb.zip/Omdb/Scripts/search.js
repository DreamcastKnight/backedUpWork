const KEY = "de614a97"
let searched = document.getElementById("movie")
function find() {
    let sendit = document.createElement('p');
    fetch("http://www.omdbapi.com/?i=tt3896198&apikey=" + KEY + "&s=" + searched.value)
        .then(res => res.json())
        .then(data => printSearch(data));
}

function extraImage(post) {
    if (post === "N/A") {
        return "https://pbs.twimg.com/profile_images/1185757909604425729/FLXwFAF5_400x400.jpg";
    }
    else return post;
}

function printSearch(data) {

    data.Search.forEach(s => {
        let card = document.createElement('div');
        card.addEventListener('click', () => window.location.href = "./film.html?id=" + s.imdbID);
        card.className = "card m-5 w-200";

        let title = document.createElement('p');
        title.innerText = s.Title;
        card.appendChild(title);

        let poster = document.createElement('img');
        poster.src = extraImage(s.Poster);
        card.appendChild(poster);

        let year = document.createElement('p');
        year.innerText = s.Year;
        card.appendChild(year);

        main.appendChild(card);
    });

}